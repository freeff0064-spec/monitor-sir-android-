MONITOR SIR — ANDROID STARTER PROJECT

এই প্যাকেজটি Android Studio/Cloud Build দিয়ে APK বানানোর source project। এটি এখনই APK নয়।

অ্যাপের বৈশিষ্ট্য:
- Blank starter: কোনো student বা attendance data আগে থেকে নেই
- Excel/CSV import দিয়ে student ও attendance যোগ করা
- Offline WebView Android shell
- Android Downloads-এ Excel/Word/CSV/JSON export
- Android Print dialog দিয়ে PDF save
- App-এর নিজস্ব storage-এ local data

APK বানানোর সহজ Cloud পদ্ধতি:
1. ZIP extract করো।
2. GitHub-এ নতুন repository বানাও (যেমন monitor-sir-android)।
3. Extract করা project-এর সব ফাইল repository-তে upload করো।
4. GitHub repository > Actions-এ যাও।
5. “Build Monitor Sir APK” workflow নির্বাচন করে Run workflow চাপো।
6. Build সফল হলে workflow run-এর নিচে Artifacts থেকে Monitor-Sir-APK.zip নামাও।
7. ZIP extract করে app-debug.apk ফোনে install করো।

গুরুত্বপূর্ণ:
- Debug APK সরাসরি শেয়ার করে ইনস্টল করা যায়, তবে এটি Play Store release-signed APK নয়।
- APK ইনস্টল করতে Android-এ “Install unknown apps” অনুমতি দিতে হতে পারে।
- Excel workbook-এর import format: প্রতিটি sheet-এ Roll, Name এবং date columns থাকতে হবে; date cell-এ P/A বা Present/Absent থাকতে হবে।
- প্রথমে sample Excel দিয়ে পরীক্ষা করো এবং নিয়মিত JSON backup রাখো।
